#!/bin/bash

samtools=`which samtools`
( [ -z "$samtools" ] || [ ! -x $samtools ] ) && echo "set samtools path first (see http://www.htslib.org/download/) !" && exit -1

genomePath=EXAMPLES/HUMAN_GENOME_GRCh37.75/Homo_sapiens.GRCh37.75.dna.toplevel.fa
genomeIndexPath=EXAMPLES/HUMAN_GENOME_GRCh37.75/Homo_sapiens.GRCh37.75.dna.toplevel.fa.fai

echo $genomePath
if [ ! -f $genomePath ]; then
	echo "download genome file"
	wget  -O $genomePath.gz ftp://ftp.ensembl.org/pub/release-75/fasta/homo_sapiens/dna/Homo_sapiens.GRCh37.75.dna.toplevel.fa.gz
	gunzip $genomePath.gz
fi

if [ ! -f $genomeIndexPath ]; then
	echo "build genome fasta index"
	$samtools faidx $genomePath
fi

echo "simulate counts" 
java -jar empires.jar  simulatecounts \
	 -transcriptsToSimulate EXAMPLES/simulate_transcript_counts/transcripts.to.simulate \
	 -incounts EXAMPLES/simulate_transcript_counts/simul.stem \
         -diffexp EXAMPLES/simulate_transcript_counts/input.truediffexp \
         -diffsplic EXAMPLES/simulate_transcript_counts/input.truesplic \
         -gtf EXAMPLES/Homo_sapiens.GRCh37.75.gtf \
         -od EXAMPLES/simulate_transcript_counts/TEST_OUTPUT/


echo "generate reads and ideal mapping bams"

java -jar empires.jar generatereads \
	 -gtf EXAMPLES/Homo_sapiens.GRCh37.75.gtf \
         -genome $genomePath \
         -genomeidx $genomeIndexPath \
         -trcounts EXAMPLES/simulate_transcript_counts/TEST_OUTPUT/transcript_exprs.txt \
         -od EXAMPLES/simulate_reads/TEST_OUTPUT


echo "sort ideal mapping bams"

for bam in `find EXAMPLES/simulate_reads/TEST_OUTPUT/ -name "*.bam"`
do
	prefix=`echo $bam | awk -F".bam" '{print $1}'`
	$samtools sort $bam -o ${prefix}_sorted.bam
done

echo "derive ECM counts from ideal mapping bams"

java -jar empires.jar ecfrombams \
	-table EXAMPLES/simulate_reads/TEST_OUTPUT/sample.table \
        -gtf EXAMPLES/Homo_sapiens.GRCh37.75.gtf \
        -o EXAMPLES/stem_idealmapping_ecm.counts \
        -basedir EXAMPLES/simulate_reads/TEST_OUTPUT/

echo "create diffexp/diffsplic table from ideal mapping bams + evaluate with trues"
java -jar empires.jar diffexp_diffsplic_on_eccounts \
	-i EXAMPLES/stem_idealmapping_ecm.counts \
        -samples EXAMPLES/simulate_reads/TEST_OUTPUT/sample.table \
        -truesplicing EXAMPLES/simulate_transcript_counts/TEST_OUTPUT/diffsplic.trues \
        -truediffexp EXAMPLES/simulate_transcript_counts/TEST_OUTPUT/diffexp.trues \
        -o EXAMPLES/empires_outtable_stem_simulation_on_ideal_mapping.tsv 


echo "create ECM-mapping reference"

java -jar empires.jar   buildindex\
	-gtf EXAMPLES/Homo_sapiens.GRCh37.75.gtf \
        -genome $genomePath \
        -genomeidx $genomeIndexPath \
        -o EXAMPLES/mapping_reads_to_ECMs/human.GRCh37.65.ecm.ref


echo "create ECM-counts with ECM-mapping"
java -jar empires.jar  ecmapper \
	-index EXAMPLES/mapping_reads_to_ECMs/human.GRCh37.65.ecm.ref \
        -table EXAMPLES/simulate_reads/TEST_OUTPUT/sample.table \
        -basedir EXAMPLES/simulate_reads/TEST_OUTPUT/ \
        -o EXAMPLES/stem_ecm_mapping_ecm.counts


echo "create diffexp/diffsplic table from ECM-mapping counts + evaluate with trues"

java -jar empires.jar diffexp_diffsplic_on_eccounts \
	-i EXAMPLES/stem_ecm_mapping_ecm.counts \
        -samples EXAMPLES/simulate_reads/TEST_OUTPUT/sample.table \
        -truesplicing EXAMPLES/simulate_transcript_counts/TEST_OUTPUT/diffsplic.trues \
        -truediffexp EXAMPLES/simulate_transcript_counts/TEST_OUTPUT/diffexp.trues \
        -o EXAMPLES/empires_outtable_stem_simulation_on_ecm_mapping_counts.tsv 
